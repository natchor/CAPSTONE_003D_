Dependencias

npm install i firebase @angular/fire
