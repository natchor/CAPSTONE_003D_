export interface User{
    uid: string,
    nombre:string,
    edad:number,
    email:string, 
    password:string,
}