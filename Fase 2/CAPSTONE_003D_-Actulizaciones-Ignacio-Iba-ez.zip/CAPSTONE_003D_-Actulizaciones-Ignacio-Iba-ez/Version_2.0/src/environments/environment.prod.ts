export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBB1HKXObZvL1vBeY_sbrHsYh-fewo-fx8",
    authDomain: "proyecto-grs.firebaseapp.com",
    projectId: "proyecto-grs",
    storageBucket: "proyecto-grs.appspot.com",
    messagingSenderId: "930699256958",
    appId: "1:930699256958:web:5a737a86189435ebafe42f",
    measurementId: "G-DCNR8KQB2H"
}
};
